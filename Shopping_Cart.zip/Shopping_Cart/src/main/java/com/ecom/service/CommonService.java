package com.ecom.service;

public interface CommonService {

	public void removeSessionMessage();

}
